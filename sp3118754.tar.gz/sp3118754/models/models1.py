class Game:
    def __init__(self, nome, estilo):
        self.nome = nome
        self.estilo = estilo

gamer = []

game = Game("PalWord", "Processada")

gamer.append(game)